/**
 * Provides Neuroph connectors to Encog engine, for high performance learning rules.
 */

package org.neuroph.nnet.flat;
