/**
 * Provides base classes and basic building components for neural networks.
 * This is the core package of framework.
 */

package org.neuroph.core;

