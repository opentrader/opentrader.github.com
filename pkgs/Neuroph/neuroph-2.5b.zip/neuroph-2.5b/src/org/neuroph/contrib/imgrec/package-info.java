/**
 * Provides classes for image recognition with neural networks.
 */

package org.neuroph.contrib.imgrec;