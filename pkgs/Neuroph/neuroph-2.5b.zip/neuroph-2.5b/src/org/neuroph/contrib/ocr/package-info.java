/**
 * Provides classes for ocr with neural networks.
 */

package org.neuroph.contrib.ocr;