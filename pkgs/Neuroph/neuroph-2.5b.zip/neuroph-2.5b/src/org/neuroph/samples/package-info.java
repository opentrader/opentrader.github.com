/**
 * Provides some basic examples of how to use Neuroph.
 */

package org.neuroph.samples;