/**
 * Provides various samples for Introduction to Neural Networks book by Jeff Heaton.
 * http://www.heatonresearch.com/book/programming-neural-networks-java-2.html
 */

package org.neuroph.samples.intronn;
