What is extended VTD-XML?
This is the java version of extend VTD-XML which allows for maximum XML file size of 256 GByte using the same offset/length/depth/token concept. In addition, extended VTD-XML allows you to either memory map the XML files so they don't have to reside entirely in memory. Documentation is a separate download (vtd-xml-2.5_doc.zip) in vtd-xml download page.

Extended VTD Spec

token type: 4 bits
Depth: 5 bits
Offset: 38 bits
Length: 17 bits

For attribute names, and starting tags

Prefix Length: 7 bits
Qualified Length: 10 bits

Package Description and Naming Convension
All classes are under com.ximpleware.extended. Those classes
are:

*VTDGenHuge
*VTDNavHuge
*AutoPilotHuge
*BookMarkHuge
*NodeRecorderHuge
*TextIterHuge
...

As you can see, basically concatnate regular class names with "Huge." 


Other Difference

XMLModifier is not implemented as of this release.


Future Plan

Extended VTD will be integrated with regular upcoming releases of VTD-XML. C# version
will also be released later.
