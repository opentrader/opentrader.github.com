import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;

public class benchmarkSAX {
  public static void main(String argv[])
  {
	  long a;
        try {
            // Set up output stream
            //out = new OutputStreamWriter(System.out, "UTF8");
            SAXParserFactory factory = SAXParserFactory.newInstance();
	    factory.setNamespaceAware(true);
            File f= new File(argv[0]);
            FileInputStream fi = null;
            byte[] bt;
            fi = new FileInputStream(f);
            System.out.println(" file size "+(int)f.length());
            bt = new byte[(int)f.length()];
            fi.read(bt);       
            SAXParser saxParser = factory.newSAXParser();
             int total;
	     int fl = (int) f.length();
	     if (fl <6000)
		    total = 2000;
	    else if (fl <15000)
		    total = 800;
	    if (fl<30000)
		    total = 500;
	    else if (fl < 60000)
		    total = 300;
	    else if (fl < 120000)
		    total = 150;
	    else if (fl <500000)
		    total = 50;
	    else if (fl < 2000000)
		    total = 20;
	    else 
		    total = 5;;
	    long lt = 0;
            a = System.currentTimeMillis();
            ByteArrayInputStream bais  = new ByteArrayInputStream(bt);
            while(System.currentTimeMillis()-a <30000)
            {
		bais.reset();
                saxParser.parse( bais, (DefaultHandler) null );
                //saxParser.parse( new File(argv[0]), handler );
            }
        
            // Parse the input
            //saxParser = factory.newSAXParser();
	    for (int j = 0;j<10;j++){
            	a = System.currentTimeMillis();
            	for(int i=0;i<total;i++)
            	{
			bais.reset();
                	saxParser.parse( bais, (DefaultHandler) null );
                	//saxParser.parse( new File(argv[0]), handler );
            	}       
          	long l2 = System.currentTimeMillis();
		lt = lt + (l2 -a);
	    }
	    	System.out.println(" average parsing time ==> "+ 
			    ((float)(lt)/total/10));
		System.out.println(" performance ==> "+ 
				( ((double)fl *1000 * total)/((lt/10)*(1<<20))));
        } catch (SAXException e)
    {
           System.out.println( e);
    }
    catch (Throwable t) {
            t.printStackTrace();
        }

  }
}

