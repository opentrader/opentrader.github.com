/* 
 * Copyright (C) 2002-2006 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;

namespace benchmark
{
    class Program
    {
        static void Main(string[] args)
        {


            System.IO.FileInfo f = new System.IO.FileInfo(args[0]);
            long l, lt = 0;
            try
            {
                System.IO.FileStream fis = new System.IO.FileStream(f.FullName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                byte[] ba = new byte[(int)f.Length];
                fis.Read(ba, 0, ba.Length);
                VTDGen vg = new VTDGen();
                int fl = (int)f.Length;
                System.Console.Out.WriteLine("fl is " + fl);
                System.Console.Out.WriteLine(" 10>>11 " + (10 >> 11));
                int total;
                if (fl < 1000)
                    total = 40000;
                else if (fl < 3000)
                    total = 20000;
                else if (fl < 6000)
                    total = 4000;
                else if (fl < 15000)
                    total = 1600;
                else if (fl < 30000)
                    total = 1000;
                else if (fl < 60000)
                    total = 600;
                else if (fl < 120000)
                    total = 300;
                else if (fl < 500000)
                    total = 100;
                else if (fl < 2000000)
                    total = 40;
                else
                    total = 5;
                System.Console.Out.WriteLine("total is " + total);

                l = (System.DateTime.Now.Ticks - 621355968000000000) / 10000;
                while ((System.DateTime.Now.Ticks - 621355968000000000) / 10000 - l < 30000)
                {
                    vg.setDoc_BR(ba);
                    vg.parse(true);
                }
                for (int j = 0; j < 10; j++)
                {
                    l = (System.DateTime.Now.Ticks - 621355968000000000) / 10000;
                    for (int i = 0; i < total; i++)
                    {
                        vg.setDoc_BR(ba);
                        vg.parse(true);
                    }
                    long l2 = (System.DateTime.Now.Ticks - 621355968000000000) / 10000;
                    lt = lt + (l2 - l);
                }
                System.Console.Out.WriteLine(" average parsing time ==> " + ((double)(lt) / total / 10) + " ms");
                System.Console.Out.WriteLine(" performance ==> " + (((double)fl * 1000 * total) / ((lt / 10) * (1 << 20))));
            }
            catch (ParseException e)
            {
                System.Console.Out.WriteLine(" Not wellformed -->" + e);
            }
            catch (System.IO.IOException e)
            {
                System.Console.Out.WriteLine(" io exception ");
            }

        }
    }
}

