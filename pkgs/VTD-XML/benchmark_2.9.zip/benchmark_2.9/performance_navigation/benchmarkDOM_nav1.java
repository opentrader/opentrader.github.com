import com.ximpleware.*;
import com.ximpleware.parser.*;
import java.io.*;
import org.w3c.dom.*;
import org.w3c.*;
import org.w3c.dom.traversal.*;
import javax.xml.parsers.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class benchmarkDOM_nav1{
     public static void main(String[] args){
	File f = new File(args[0]);
	try{
	    FileInputStream fis = new FileInputStream(f);
	    byte[] ba = new byte[(int)f.length()];
	    fis.read(ba); 	    
	    //vg.setDoc(ba);
	    DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
	    factory.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false );	
	    factory.setNamespaceAware(true);
	    factory.setExpandEntityReferences(false);
	    DocumentBuilder parser = factory.newDocumentBuilder();
	    ByteArrayInputStream bais = new ByteArrayInputStream(ba);

	    int total;
	    int fl = (int) f.length();
  	    if (fl <1000)
		    total =40000;
	    else if (fl< 3000)
		    total =20000;
	    else if (fl <6000)
		    total = 4000;
	    else if (fl <15000)
		    total = 1600;
	    else if (fl<30000)
		    total = 1000;
	    else if (fl < 60000)
		    total = 600;
	    else if (fl < 120000)
		    total = 300;
	    else if (fl <500000)
		    total = 100;
	    else if (fl < 2000000)
		    total = 40;
	    else 
		    total = 5;	
	    long l,lt=0;
 	    int whatToShow 
    		= NodeFilter.SHOW_ALL;
	    Document d = parser.parse(bais);
	    DocumentTraversal traversable = (DocumentTraversal) d;
            for (int i=0;i<total;i++){
	          NodeIterator iterator = traversable.createNodeIterator(d, 
     		     whatToShow, null, true);
   	          while (iterator.nextNode()!= null) {
		     //System.out.println("iterating");
    	         }
	    }
	    for(int j=0;j<10;j++) {	
		l = System.currentTimeMillis();
                for (int i=0;i<total;i++){
	          NodeIterator iterator = traversable.createNodeIterator(d, 
     		     whatToShow, null, true);
   	          while (iterator.nextNode()!= null) {
		     //System.out.println("iterating");
    	          }
		}
	       	long l2 = System.currentTimeMillis();
		//System.out.println(" time spent --> "+(l2-l)+" ms");
                lt = lt+ (l2-l);
	    } 
	    
       	    System.out.println("DOM "+args[0]+" average iteration latency ==> "+ 
			    ((float)(lt)/total/10)+" ms");
	}
	catch (Exception e){
		System.out.println("exception ==> "+e);
	} 
     }	
} 
